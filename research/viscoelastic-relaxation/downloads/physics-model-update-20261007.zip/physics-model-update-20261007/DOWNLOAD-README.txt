Physics model update, 7 October 2026

Start with research/viscoelastic-relaxation/report.pdf (7 pages).
The 19-page full experimental report and symbolic notation article are also included.

This is isolated research, not a replacement native physics engine.
The rolling improvement is exploratory reuse of a small experimental split;
the rock viscoelastic extension failed and is retained. Mechanical controls and
local kernel costs do not establish full empirical or interacting-group validation.
Documented material inputs and native production source are unchanged.

To reproduce the NEW study, extract the whole folder, install NumPy/SciPy/Matplotlib,
and follow research/viscoelastic-relaxation/README.md using new output directories.
The data dependencies for that study are included. g++ and pdflatex are needed
for the optional local benchmark and PDF rebuild. Third-party source PDFs and
native engine binaries are not redistributed. Earlier report-wide reproduction
requires its separate evidence bundle or the complete live repository.
